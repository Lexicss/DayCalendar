package com.example.socialnetworktest;

import winterwell.jtwitter.OAuthSignpostClient;
import winterwell.jtwitter.Twitter;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

import com.facebook.android.AsyncFacebookRunner;
import com.facebook.android.DialogError;
import com.facebook.android.Facebook;
import com.facebook.android.Facebook.DialogListener;
import com.facebook.android.FacebookError;

public class MainActivity extends Activity {

    Facebook facebook = new Facebook("557167997633418");
    AsyncFacebookRunner mAsyncRunner = new AsyncFacebookRunner(facebook);

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        facebook.authorize(this, new DialogListener() {
            @Override
            public void onComplete(Bundle values) {}

            @Override
            public void onFacebookError(FacebookError error) {}

            @Override
            public void onError(DialogError e) {}

            @Override
            public void onCancel() {}
        });
    }
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        Twitter twitter = new Twitter();
        twitter.account();
        OAuthSignpostClient oauthClient = new OAuthSignpostClient("fCr2aKBGhYZWx3fMm62TKw", 
        		"XHAQ5Z9vGK7K3fyTyXgnV5lT3x8kSeVbTvtjhttxjU", "oob");
        oauthClient.authorizeDesktop();
        
        
        facebook.authorizeCallback(requestCode, resultCode, data);
    }
}
